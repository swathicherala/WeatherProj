<template> 
  <div class="home">
   <!-- Carousel -->
    <div class="row">
      <div class="col-sm-12">
      <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators move">
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active imageslider">        
            <img src="./images/home1.jpg" class="image" alt="...">
            <p class="para">Welcome To Guybrand Limited</p>
          </div>
          <div class="carousel-item imageslider">
            <img src="./images/home2.jpg" class="image" alt="...">
            <p class="para">Design, Planning & Build</p>
          </div>
          <div class="carousel-item imageslider">
            <img src="./images/home3.jpg" class="image" alt="...">
           <p class="para">Project Management</p>
          </div>
        </div>
      </div>
      </div>
      </div>
    <!-- Carousel End -->
    <!-- GUYBrand Limited -->
    <GuyBrandLTD />
    <!-- GUYBrand Limited End -->
  </div>
</template>


<script>
import GuyBrandLTD from './GuyBrandLTD'
export default {
  name: 'HomeView',
  components: { 
    GuyBrandLTD,
  }
}
</script>

<style scoped>
.imageslider img{
  width:900px;
  height:500px;
}
.home{
margin-top:-10px;
padding-top:0px;
}
.move button{
 background-color: orange;
}
.para{
    left: 0;
  position: absolute;
  text-align: center;
  top: 50%;
  width: 100%;
  font-size:20px;
  font-weight: bold;
  color:black;
}
.image{
  opacity:0.9;
}
.move{
  padding-left:80px;
}
</style>

