<template>
   <div class="services">
    <img src="./images/services.jpg">
    <ServicesView2 />
  </div>
</template>

<script>
import ServicesView2 from './ServicesView2'
export default{
    name: 'ServicesView',
    components:{
        ServicesView2
    }
}
</script>

<style scoped>
.services img{
  width:900px;
  height:280px;
}
</style>