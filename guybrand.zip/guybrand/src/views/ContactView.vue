<template>
   <div class="contact">
    <img src="./images/contact.jpg">
    <ContactView2 />
  </div>
</template>

<script>
import ContactView2 from './ContactView2'
export default{
    name:'ContactView',
    components:{
      ContactView2
    }
}
</script>

<style scoped>
.contact img{
  width:900px;
  height:280px;
}
</style>
