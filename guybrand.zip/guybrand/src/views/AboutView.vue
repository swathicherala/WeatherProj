<template>
  <div class="about">
    <img src="./images/about.jpg">
    <AboutView2 />
  </div>
</template>

<script>
import AboutView2 from './AboutView2'
export default{
  name:'AboutView',
  components:{
    AboutView2
  }
}
</script>

<style scoped>
.about img{
  width:900px;
  height:280px;
}
</style>