
<template>
<div  class="main">
  <div class="container">
      <div>
          <h1 class="text">
              Guybrand Limited
                <hr style="background-color:blue"/>
          </h1>
        
          <p class="info">
              Guybrand Limited is a family-run building company. Every home is unique and should be perfectly built and designed to meet your needs. The Guybrand Limited team is made up of talented and experienced building professionals who will discuss all the options available and work with you to develop the best solution for your home.
          </p>
      </div>
    <div class="row mt-5">
      <div class="col-md-6">
        <p class="text2">When it comes to any building project, there is a wealth of information available and the options can be overwhelming. Whether you’re starting the process of working your way up the property ladder, remodelling your living space, or building a dream home, it can be tricky to know where to start. We are here to support you on every step of the journey.</p>
      </div>
      <div class="col-sm-6">
       <img src="./images/LTD1.jpg" width="350">
      </div>
    </div>

    <div class="row mt-5">
      <div class="col-sm-6">
       <img src="./images/LTD2.jpg" width="350">
      </div>
      <div class="col-md-6">
         <p class="text2">The Guybrand Limited building expertise is vast. We undertake all types of projects – from new builds, extensions and conversions to high-end renovations, as well as commercial work. Whatever the size or scope of your project, you can be confident that Guybrand Limited will deliver with meticulous care, great value and efficiency.</p>
      </div>
    </div>

    <div class="row mt-5">
      <div class="col-md-6">
        <h1 class="text">
            Read to go?
        </h1>
        <p class="text3">
            If you have architectural plans and are looking for professional builders, find out more about the Guybrand Limited Bespoke Build service.
        </p>
      </div>
      <div class="col-sm-6">
       <h1 class="text">
           Just Starting Out?
       </h1>
       <p class="text3">
           If you’re at the beginning of your journey and need someone to take care of everything, find out more about the Guybrand Limited Design, Planning & Build service.
       </p>
      </div>
    </div>
  </div>
</div>
</template>

<style scoped>
.main{
    background-image: url('./images/background.jpg');
}
p{
  text-indent: 50px;
  text-align: justify;
}
.text{
    font-size:20px;
    color:orange;
    font-family: Copperplate,Copperplate Gothic Light,fantasy;
    font-weight: bold;
    margin:25px 0px;
}
.info{
    text-align: justify;
    word-spacing: 2px;
    font-size: 14px;
    text-indent: 0;
    color:white;
}
.text2{
    text-indent: 0px;
    margin-top:150px;
    word-spacing: 4px;
    color:white
}
.text3{
    word-spacing: 4px;
    color:white;
    text-indent: 0px;
    font-size:12px;
}

</style>




