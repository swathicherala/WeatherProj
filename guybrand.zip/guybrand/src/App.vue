<template>
  <div>
    <nav class="navbar navbar-expand-sm bg-light fixed-top">
          <img src="./views/images/logo.svg" class="navbar-brand">  
          <ul class="navbar-nav mainnav">
          <li class="nav-item listing">
            <router-link to="/" class="nav-link linkpage"><span>Home</span></router-link> 
          </li>
          <li class="nav-item listing">          
         <router-link to="/about" class="nav-link linkpage"><span>About</span></router-link>
          </li>
          <li class="nav-item listing">
            <router-link to="/services" class="nav-link linkpage"><span>Services</span></router-link>
          </li>
          <li class="nav-item listing">
            <router-link to="/contact" class="nav-link linkpage"><span>Contact</span></router-link>
          </li>
          </ul> 
  </nav>
  <router-view/>
  <FooterView />
      </div>
</template>

<script>
import FooterView from './views/FooterView'
export default{
  name:'App',
  components:{
    FooterView
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
nav {
  padding: 30px 30px 0px 30px;
  margin-bottom: 0px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

.mainnav{
  margin-left:250px;
}

nav a.router-link-exact-active {
  color:blue;
  text-decoration: none;
}

.navbar-brand{
  margin-top:0px;
  padding-top: 0px;
  width:19%;
  height: 90%;
  margin-top:-10px;
  padding-left:30px;
}
.listing{
  list-style: none;
}
.linkpage span{
  color:grey;
  text-transform: uppercase;
  padding:14px;
  font-size:14px;
}
span:hover{
  color:blue;
  text-decoration: none;
}



</style>
