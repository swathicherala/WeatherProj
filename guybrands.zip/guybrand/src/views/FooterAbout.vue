<template>
<div class="main1">
  <div class="container">
      <div class="row">
        <div class="col-sm-4 foot">
          <div>
              <img src="./images/logo.svg" class="image2">
          </div>
          <ul class="listing">
              <li>
                  <router-link to="/">Home</router-link>
              </li>
              <li>
                  <router-link to="/about" v-if="HideHome">About</router-link>
              </li>
              <li>
                  <router-link to="/serices">Services</router-link>
              </li>
              <li>
                  <router-link to="/contact">Contact</router-link>
              </li>
          </ul>
        </div>

        <div class="col-sm-4 foot2">
            <h1 class="heading">
                Get in touch
                <hr/>
            </h1>
            <div class="address">
                <p class="texts">
                Please feel free to get in touch with us regarding any of our services using the following details
            </p>
            <ul class="footerlist">
                <li>
                   Office 973,<br/>
                   58 Peregrine Road,<br/>
                   Ilford IG6 3SZ
                </li>
                <li>
                    Phone: 0207 183 0754
                </li>
                <li>
                    Email: <a href="" style="text-decoration:none;">sales@guybrand.co.uk</a>
                </li>
            </ul>
            </div>
        </div>

        <div class="col-sm-4">
            <h1 class="heading">
                Where we are
            </h1>
            <hr />
            <div>
                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d9910.678011269529!2d0.125367!3d51.61094400000001!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47d8a391bf87eca5%3A0xab394731bb9cc927!2s973%2C%2058%20Peregrine%20Rd%2C%20Ilford%20IG6%203SZ%2C%20UK!5e0!3m2!1sen!2sin!4v1654517510622!5m2!1sen!2sin" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"  class="map">
                </iframe>
            </div>
        </div>
    </div>
  </div>
</div>
</template>

<script>
export default{
    name:'FooterView',
    data(){
        return{
            HideHome:false
        }
    }
}
</script>

<style scoped>
.main1{
    background-color:rgb(190, 187, 187);
}

.heading{
    color:#2f7ef5;
    font-size:15px;
    text-align: left;

}
.texts{
    text-indent: 0px;
}
.listing li{
list-style:none;

padding:3px;
font-size: 12px;
margin-right:12px;
}
.listing{
    margin-top:-15px;
    padding-right:10px;
}
.listing li a{
    text-decoration: none;
    font-size: 14px;
}
hr{
    background-color:blue;
}
.map{
    width:200px;
    height:150px;
}
.footerlist li{
    text-align: left;
    font-size: 12px;
    font-weight: bold;
}
.image2{
    margin-top:-14px;
    width:80px;
    height:90px;
}
@media only screen and (max-width:500px){
.texts .footerlist{
    text-align: center;
}
.foot{
    text-align: center;
}
.foot2{
    justify-content: center;
}
.texts{
    text-indent: 14px;
}
.heading{
    text-align: center;
}
.footerlist{
    width: 30%;
    margin:auto;
    padding-bottom: 20px;
}
}

</style>